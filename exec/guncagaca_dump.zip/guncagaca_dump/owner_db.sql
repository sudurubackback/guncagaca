-- MySQL dump 10.13  Distrib 8.1.0, for macos13.3 (arm64)
--
-- Host: k9d102a.p.ssafy.io    Database: owner_db
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `approval` bit(1) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business`
--

DROP TABLE IF EXISTS `business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business` (
  `business_id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `business_number` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `open_date` date DEFAULT NULL,
  `owner_id` bigint DEFAULT NULL,
  `address` varchar(500) NOT NULL,
  `business_name` varchar(500) NOT NULL,
  `ddns` bigint DEFAULT NULL,
  `img` varchar(500) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`business_id`),
  KEY `FKipge3kluyb8am8wepmgvyu6en` (`owner_id`),
  CONSTRAINT `FKipge3kluyb8am8wepmgvyu6en` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business`
--

LOCK TABLES `business` WRITE;
/*!40000 ALTER TABLE `business` DISABLE KEYS */;
INSERT INTO `business` VALUES (1,'2023-11-03 05:52:53.035628','2023-11-03 05:52:53.035628','1111111','5138531684','정해린','2013-12-01',4,'구미 싸피','은지니 최고',NULL,'',NULL,NULL),(2,'2023-11-03 06:09:57.854681','2023-11-03 06:09:57.854681','1111111','5138531684','정해린','2013-12-01',NULL,'구미 싸피','은지니 최고',NULL,'',NULL,NULL),(3,'2023-11-03 06:52:49.020832','2023-11-03 06:52:49.020832','1111111','5138531684','정해린','2013-12-01',NULL,'구미 싸피','은지니 최고',NULL,'',NULL,NULL),(4,'2023-11-06 01:16:03.021039','2023-11-06 01:16:03.021039','1111111','5138531684','정해린','2013-12-01',NULL,'구미 싸피','은지니 최고',NULL,'',NULL,NULL),(5,'2023-11-06 07:37:47.853450','2023-11-06 07:37:47.853450','1111111','5138531684','정해린','2013-12-01',NULL,'구미 싸피','은지니 최고',NULL,'',NULL,NULL),(6,'2023-11-06 07:39:21.266869','2023-11-06 07:39:21.266869','1111111','5138531684','정해린','2013-12-01',NULL,'구미 싸피','은지니 최고',NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `business` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners`
--

DROP TABLE IF EXISTS `owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owners` (
  `owner_id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `validation` bit(1) NOT NULL,
  `business_id` bigint DEFAULT NULL,
  `store_id` bigint DEFAULT NULL,
  `admin_id` bigint DEFAULT NULL,
  `ddns` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`owner_id`),
  KEY `FKcpukqo6xneuu24orn5sh23sau` (`business_id`),
  KEY `FKaqlwgi43r4c3tej1xkv9i0l18` (`admin_id`),
  CONSTRAINT `FKaqlwgi43r4c3tej1xkv9i0l18` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`),
  CONSTRAINT `FKcpukqo6xneuu24orn5sh23sau` FOREIGN KEY (`business_id`) REFERENCES `business` (`business_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners`
--

LOCK TABLES `owners` WRITE;
/*!40000 ALTER TABLE `owners` DISABLE KEYS */;
INSERT INTO `owners` VALUES (1,NULL,'2023-11-14 13:16:40.837284','e@e','{bcrypt}$2a$10$0Az3POtJKlkaFCX/Eq1JDOL22tI6VWZQMNh.T3Pv1rKVY2M5/2AMO','010-1234-1234',_binary '\0',NULL,1,NULL,NULL,'1111',NULL),(2,'2023-11-02 07:48:41.426346','2023-11-02 07:48:41.426346','a@naver.com','$2a$10$Kky4zcKfVBWGJVZin8GeeOZOVajDwAOnnfrIH3nEZ1oE29T2b1Q.2','010-1234-1234',_binary '\0',NULL,NULL,NULL,NULL,NULL,NULL),(3,'2023-11-03 05:36:04.032477','2023-11-03 05:36:04.032477','c@naver.com','$2a$10$LVkshmqyR/Mx/bWLqszcDOhXUyc3YpCWj4YfTiAqYeXb3IxO1rcMK','010-1234-1234',_binary '\0',NULL,NULL,NULL,NULL,NULL,NULL),(4,'2023-11-03 05:50:29.287882','2023-11-03 05:50:29.287882','d@naver.com','$2a$10$7fyx0IB0MlDQp/sXalgmZOFQawXfJFA8LhyQupwkO0A9AN.SNHGFS','010-1234-1234',_binary '\0',NULL,NULL,NULL,NULL,NULL,NULL),(5,'2023-11-03 06:53:40.180234','2023-11-06 04:43:10.332948','e@naver.com','$2a$10$KV1hvHrKJF5Fp81TWtiTMOoP7bkwrs4cqUz7f2jFDZzbyL3dyjl96','010-1234-1234',_binary '\0',3,13,NULL,NULL,NULL,NULL),(6,'2023-11-06 07:38:05.334416','2023-11-06 07:38:05.334416','e@naver.com','$2a$10$70XNVQG2oRSPH76n2tMU3.uZQ/SvmF1QXYrkfIZVJioIEc0JUM5EC','010-1234-1234',_binary '\0',5,NULL,NULL,NULL,NULL,NULL),(7,'2023-11-06 07:39:30.543643','2023-11-06 07:39:30.543643','q@q','$2a$10$BzfzjdxpkwNruSoZp.gciuHR9wIVX9iq7w83hZpd4zK8ih3ejKNJm','010-1234-1234',_binary '\0',6,8,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `store_id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(500) NOT NULL,
  `close_time` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `img` varchar(500) DEFAULT NULL,
  `is_open` bit(1) NOT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `name` varchar(500) NOT NULL,
  `open_time` varchar(255) DEFAULT NULL,
  `star_point` double NOT NULL,
  `tel` varchar(255) NOT NULL,
  `owner_id` bigint DEFAULT NULL,
  `owners_id` bigint DEFAULT NULL,
  PRIMARY KEY (`store_id`),
  KEY `FK3fumnfy6y9t88bavyuiw6abpc` (`owner_id`),
  KEY `FKgimw9mh3gxs2q2s5tctnb85mb` (`owners_id`),
  CONSTRAINT `FK3fumnfy6y9t88bavyuiw6abpc` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`owner_id`),
  CONSTRAINT `FKgimw9mh3gxs2q2s5tctnb85mb` FOREIGN KEY (`owners_id`) REFERENCES `owners` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'owner_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 11:55:11
