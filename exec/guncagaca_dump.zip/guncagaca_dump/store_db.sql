-- MySQL dump 10.13  Distrib 8.1.0, for macos13.3 (arm64)
--
-- Host: k9d102a.p.ssafy.io    Database: store_db
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alert_history`
--

DROP TABLE IF EXISTS `alert_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `body` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `member_id` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_history`
--

LOCK TABLES `alert_history` WRITE;
/*!40000 ALTER TABLE `alert_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likey`
--

DROP TABLE IF EXISTS `likey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likey` (
  `like_id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` bigint DEFAULT NULL,
  `store_store_id` bigint DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`like_id`),
  KEY `FK8xk0f1xns39bm8lip41j6e3so` (`store_store_id`),
  CONSTRAINT `FK8xk0f1xns39bm8lip41j6e3so` FOREIGN KEY (`store_store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likey`
--

LOCK TABLES `likey` WRITE;
/*!40000 ALTER TABLE `likey` DISABLE KEYS */;
INSERT INTO `likey` VALUES (40,4,9,NULL,NULL),(43,5,8,'2023-11-16 05:24:04','2023-11-16 05:24:04'),(44,7,8,'2023-11-17 01:52:54','2023-11-17 01:52:54');
/*!40000 ALTER TABLE `likey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `comment` varchar(500) NOT NULL,
  `member_id` bigint DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `star` double NOT NULL,
  `store_store_id` bigint DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FK631y6sa1tv0vkokcvtd8v4fvb` (`store_store_id`),
  CONSTRAINT `FK631y6sa1tv0vkokcvtd8v4fvb` FOREIGN KEY (`store_store_id`) REFERENCES `store` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'맛있어요',4,'1',5,8,NULL,NULL),(2,'배부르다',5,'6546a9126dd7c85f45fa80a8',4.5,8,NULL,NULL),(3,'잘먹었습니다',8,'6546a9126dd7c85f45fa80a8',5,8,NULL,NULL),(4,'not bad',7,'6546a6566dd7c85f45fa80a7',4,8,NULL,NULL),(5,'굿굿',6,'6546a4b76dd7c85f45fa80a6',5,8,NULL,NULL),(6,'사장님이 친절하게 대해주세요\r ',4,'6547faa1f2aaca104194bd16',5,8,NULL,NULL),(7,'맛있는 커피랑 카페 분위기가 제 취향이에요',5,'6549ae3183624b2b7522e5de',5,8,NULL,NULL),(8,'가게 분위기가 좋아요',8,'654ba313f2a2b817e5223b54',5,9,NULL,NULL),(9,'크로와상이 참 맛납니다,,,,',5,'6546a0ad6dd7c85f45fa80a5',3,8,NULL,NULL),(10,'사장님이 친절해요',6,'654dc068f2a2b817e5223b6f',5,8,NULL,NULL),(46,'존맛탱',7,'655377a7581c9a31efed86f4',4,8,'2023-11-15 06:13:47','2023-11-15 06:13:47'),(47,'단골입니다~~',5,'6555b2c161d1a85d0c85d771',5,8,'2023-11-16 06:33:10','2023-11-16 06:33:10'),(48,'good taste!',5,'6555b7e461d1a85d0c85d772',5,8,'2023-11-16 06:46:19','2023-11-16 06:46:19');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `store_id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(500) NOT NULL,
  `description` varchar(255) NOT NULL,
  `img` varchar(500) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `name` varchar(500) NOT NULL,
  `star_point` double DEFAULT NULL,
  `tel` varchar(255) NOT NULL,
  `close_time` varchar(255) DEFAULT NULL,
  `is_open` bit(1) NOT NULL,
  `open_time` varchar(255) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (8,'인의동 840-2','커피비치 인동구미점입니다.','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRS7Qve8hl7bubnMWjq4xPsOsamU-3iyEczDL2WzcYiNQ&s',36.103937,128.4222342,'커피비치 구미인동점',4.833333333333333,'010-0000-0000','08:00 PM',_binary '','10:00 AM',NULL,NULL,NULL),(9,'인동중앙로6길 7','더로드커피입니다. 디저트 맛있습니다.','https://mblogthumb-phinf.pstatic.net/MjAyMzA0MzBfMiAg/MDAxNjgyODQzMDA3MjA3.ZoDXDMzyfLzYxs2NmLAiNN7z828slQKti-jO2wlj_mEg.kD5qvsLmXYXBvYgIR65aKIKOMTpYPYVUDOxBll5Gp2wg.JPEG.anotherplops/IMG_6975.jpg?type=w800',36.1070615,128.4219085,'더로드 커피',5,'010-0000-0000','11:59 PM',_binary '','00:00 AM',NULL,NULL,NULL);
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'store_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 11:47:07
