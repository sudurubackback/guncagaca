-- MySQL dump 10.13  Distrib 8.1.0, for macos13.3 (arm64)
--
-- Host: k9d102a.p.ssafy.io    Database: member_db
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (2,'test4@test.com','test4',NULL,NULL,NULL),(3,'hara0822@naver.com',NULL,NULL,NULL,NULL),(4,'dudxo7721@naver.com','ㅎㅎㅎㅎ',NULL,NULL,'2023-11-14 10:58:57.264382'),(5,'hoilday5303@naver.com','김제준','fdgcw4xpTSe5Kb9OziHtSQ:APA91bHerqCNodiMDuzhEbWzMepISTPAy_zcH9Ys_WhId-ZQyNsBJSAeJW8OkB45syRK-8jThaZrVdlqdx2ynylfl6VoIoQOyKX6tU50cPru32HyaM4iP8_FTdS5RvSjYDZtjo5wnf_O',NULL,'2023-11-16 00:09:27.434532'),(6,'minseung813@naver.com','minseung',NULL,NULL,NULL),(7,'skrud5985@naver.com','권민재','e6J27Ie-Q6Csdi61CCOrZN:APA91bF9nO4dUNa0VFyht01efoANCeuSM2blZ-PNCxwGZ8KfE2vdrSyVbH6H_avCzD2Io_alPoebSmqURN80rhRL8X-YDlFzvrW95PhNJmjSOInMwh_yMFzkplQkQlWeh3yInX-C01ST',NULL,'2023-11-16 14:38:43.809016'),(8,'rlvy98@nate.com','이기표','c5PA8unLR_iB8tXX0qeJRC:APA91bFzePzuVms8rzsCRfdPdiajsLqgwGNTjuN17jg07k-cHmYHVlIK-gRzaNcDk-mjIoB6oG1QnWKtx3W20guqmjUZM8eJJ27QClhk7OAmSMN_4nyS3f-Q94oOKwaIhfJNzgmOOlzi',NULL,NULL),(9,'test','yt','string',NULL,NULL),(10,'email','닉네임',NULL,NULL,NULL),(11,'ilikloud101@gmail.com','운이좋아',NULL,NULL,'2023-11-13 08:56:59.316165'),(12,'q@q',NULL,NULL,'2023-11-13 08:54:00.361036','2023-11-13 08:54:00.361036');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `point`
--

DROP TABLE IF EXISTS `point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `point` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `point` int NOT NULL,
  `store_id` bigint DEFAULT NULL,
  `member_member_id` bigint DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfpgak1wlljsio64xd7u74g3bx` (`member_member_id`),
  CONSTRAINT `FKfpgak1wlljsio64xd7u74g3bx` FOREIGN KEY (`member_member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `point`
--

LOCK TABLES `point` WRITE;
/*!40000 ALTER TABLE `point` DISABLE KEYS */;
INSERT INTO `point` VALUES (1,200,8,7,NULL,NULL),(2,1000,9,7,NULL,NULL),(3,500,8,7,NULL,NULL);
/*!40000 ALTER TABLE `point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'member_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 11:50:32
